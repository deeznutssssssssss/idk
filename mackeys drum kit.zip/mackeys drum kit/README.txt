Yo if someone sold this to YOU and you bought it please request a refund immediately.
Anyway make a good beat if your using it
